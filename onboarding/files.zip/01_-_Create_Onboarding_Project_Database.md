# Create Onboarding Project Database

1. Open **SQL Server Management Studio** and connect to your SQL Server.

   Credentials for SQL Server:

   - IP: **192.168.100.23**
   - Username: **sa**
   - Password: **1qaz!QAZ**

2. Create a new database and name it **"SixtyThreeBitsOnboardingYourName"**.

   ![](images/image1.png)

   ![](images/image2.png)

3. Right-click on your new database and choose **New Query**. A new query window will open.

   ![](images/image3.png)

4. Go to your hard drive and open the **SixtyThreeBitsOnboarding.sql** file. Copy all scripts from this file and paste them into the new query window. It should look something like this:

   ![](images/image4.png)

5. Make sure you have selected your database for the new query window, then click the **Execute** button:

   ![](images/image5.png)

   This script is designed to create a standardized database structure, including tables, stored procedures, and functions.
